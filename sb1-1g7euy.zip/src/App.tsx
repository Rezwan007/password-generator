import React from 'react';
import PasswordGenerator from './components/PasswordGenerator';

function App() {
  return <PasswordGenerator />;
}

export default App;