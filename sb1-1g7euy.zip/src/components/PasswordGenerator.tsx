import React, { useState } from 'react';
import { Copy, RefreshCw, Shield } from 'lucide-react';

interface PasswordOptions {
  length: number;
  uppercase: boolean;
  lowercase: boolean;
  numbers: boolean;
  symbols: boolean;
}

export default function PasswordGenerator() {
  const [password, setPassword] = useState('');
  const [options, setOptions] = useState<PasswordOptions>({
    length: 16,
    uppercase: true,
    lowercase: true,
    numbers: true,
    symbols: true,
  });
  const [copied, setCopied] = useState(false);

  const generatePassword = () => {
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';

    let chars = '';
    if (options.uppercase) chars += uppercase;
    if (options.lowercase) chars += lowercase;
    if (options.numbers) chars += numbers;
    if (options.symbols) chars += symbols;

    if (!chars) return;

    let generatedPassword = '';
    for (let i = 0; i < options.length; i++) {
      const randomIndex = Math.floor(Math.random() * chars.length);
      generatedPassword += chars[randomIndex];
    }
    setPassword(generatedPassword);
    setCopied(false);
  };

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(password);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-black text-green-500 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <Shield className="mx-auto h-12 w-12 mb-4" />
          <h1 className="text-4xl font-bold mb-2">Password Generator</h1>
          <p className="text-green-400">Generate secure, random passwords</p>
        </div>

        <div className="relative">
          <div className="bg-gray-900 p-4 rounded-lg border border-green-500/30 flex items-center gap-2">
            <input
              type="text"
              value={password}
              readOnly
              className="w-full bg-transparent outline-none font-mono"
              placeholder="Generated password"
            />
            <button
              onClick={copyToClipboard}
              className="p-2 hover:bg-green-500/10 rounded-md transition-colors"
              title="Copy to clipboard"
            >
              <Copy className={copied ? 'text-green-400' : ''} size={20} />
            </button>
            <button
              onClick={generatePassword}
              className="p-2 hover:bg-green-500/10 rounded-md transition-colors"
              title="Generate new password"
            >
              <RefreshCw size={20} />
            </button>
          </div>
          {copied && (
            <span className="absolute -top-8 right-0 text-sm text-green-400">
              Copied to clipboard!
            </span>
          )}
        </div>

        <div className="space-y-4 bg-gray-900/50 p-6 rounded-lg border border-green-500/30">
          <div>
            <label className="flex justify-between mb-2">
              Length: {options.length}
              <input
                type="range"
                min="8"
                max="32"
                value={options.length}
                onChange={(e) =>
                  setOptions({ ...options, length: parseInt(e.target.value) })
                }
                className="w-2/3"
              />
            </label>
          </div>

          {[
            { key: 'uppercase', label: 'Uppercase (A-Z)' },
            { key: 'lowercase', label: 'Lowercase (a-z)' },
            { key: 'numbers', label: 'Numbers (0-9)' },
            { key: 'symbols', label: 'Symbols (!@#$...)' },
          ].map(({ key, label }) => (
            <label
              key={key}
              className="flex items-center justify-between cursor-pointer"
            >
              <span>{label}</span>
              <input
                type="checkbox"
                checked={options[key as keyof PasswordOptions]}
                onChange={(e) =>
                  setOptions({ ...options, [key]: e.target.checked })
                }
                className="w-5 h-5 rounded border-green-500 text-green-500 focus:ring-green-500 focus:ring-offset-gray-900"
              />
            </label>
          ))}
        </div>

        <button
          onClick={generatePassword}
          className="w-full py-3 px-4 bg-green-500 text-black font-semibold rounded-lg hover:bg-green-400 transition-colors"
        >
          Generate Password
        </button>
      </div>
    </div>
  );
}